(function($) {
    "use strict"; // Start of use strict
})(jQuery);